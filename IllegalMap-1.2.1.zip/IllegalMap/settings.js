import { @Vigilant, @SwitchProperty, @SliderProperty, @TextProperty, @ColorProperty, @PercentSliderProperty, Color } from '../Vigilance/index';

@Vigilant("IllegalMap")
class Settings {

    constructor() {
        this.initialize(this)
        this.setCategoryDescription('Dungeon Map', '&c&lTO MAKE THE MAP SHOW\n&c&lGO TO CONTROLS -> MAP -> REFRESH MAP\n&c&lAND SET THE KEYBIND')
        this.setSubcategoryDescription('Dungeon Map', 'Map Aethetics', 'Size, position, scale etc of map.')

        this.setCategoryDescription('World', 'Things related to rendering stuff in the world.')

        this.setCategoryDescription('Score Calculator', '&c&lWARNING\n&c&lTHIS IS NOT 100% RELIABLE\n&c&lIF A ROOM FAILS TO BE DETECTED\n&c&lTHIS WILL SHOW THE WRONG SCORE')
    }
    
    // Settings
    @SwitchProperty({
        name:"Map Enabled",
        description:"Shows the map on-screen.",
        category:"Dungeon Map",
        subcategory:"Map"
    })
    mapEnabled = true;

    @SwitchProperty({
        name:"Chat Info",
        description:"Sends information about the dungeon every time you refresh.",
        category:"Dungeon Map",
        subcategory:"Map"
    })
    mapChatInfo = true;

    @SliderProperty({
        name: "Map X",
        description: "How far across your screen the map shows.",
        category: "Dungeon Map",
        subcategory:"Map Aethetics",
        min: 0,
        max: Renderer.screen.getWidth()
    })
    mapX = 1;

    @SliderProperty({
        name: "Map Y",
        description: "How far up/down on your screen the map is.",
        category: "Dungeon Map",
        subcategory:"Map Aethetics",
        min: 0,
        max: Renderer.screen.getHeight()
    })
    mapY = 1;

    @SliderProperty({
        name: "Map Scale",
        description: "How large the map is.",
        category: "Dungeon Map",
        subcategory:"Map Aethetics",
        min: 1,
        max: 10
    })
    mapScale = 5;

    @SliderProperty({
        name: "Map Background Opacity",
        description: "How transparent the background of the map is. 255 = Not transparent, 0 = Fully transparent.",
        category: "Dungeon Map",
        subcategory:"Map Aethetics",
        min: 0,
        max: 255
    })
    backgroundTransparency = 100;

    @SwitchProperty({
        name:"&cM&ea&6p &aR&bG&dB",
        description:"Makes a thin RGB border around the map.",
        category:"Dungeon Map",
        subcategory:"Map Aethetics"
    })
    mapRGB = false

    @SwitchProperty({
        name:"Show Player Heads",
        description:"Shows player heads on the map.\n&cWARNING: Very unoptimized, may cause lag. Not super accurate lol",
        category:"Dungeon Map",
        subcategory:"Icons"
    })
    showHeads = true

    @PercentSliderProperty({
        name: "Head Icon Scale",
        description: "How large the players' head icons are.",
        category: "Dungeon Map",
        subcategory: "Icons",
    })
    headScale = 0.3;

    @SwitchProperty({
        name:"Show Player Head Names",
        description:"Shows player's names underneath their icon on the map.",
        category:"Dungeon Map",
        subcategory:"Icons"
    })
    showIconNames = false

    @SwitchProperty({
        name:"Show Own Head",
        description:"Shows your own head on the map (Even before dungeon has started).",
        category:"Dungeon Map",
        subcategory:"Icons"
    })
    showOwnHead = true

    @SwitchProperty({
        name:"Show Checkmarks",
        description:"Show checkmarks on the map.",
        category:"Dungeon Map",
        subcategory:"Icons"
    })
    showCheckmarks = true

    @SwitchProperty({
        name:"Show Important Names",
        description:"Shows the room names of only trap and puzzle.",
        category:"Dungeon Map",
        subcategory:"Map Info"
    })
    showImportantRooms = true;

    @SwitchProperty({
        name:"Show All Room Names",
        description:"Shows the room names of every room.",
        category:"Dungeon Map",
        subcategory:"Map Info"
    })
    showAllRooms = false;

    @SwitchProperty({
        name:"Show New Rooms",
        description:"Shows new rooms on the map.",
        category:"Dungeon Map",
        subcategory:"Map Info"
    })
    showNewRooms = false;

    @SwitchProperty({
        name:"Show Secrets",
        description:"Shows the secrets in each room.",
        category:"Dungeon Map",
        subcategory:"Map Info"
    })
    showSecrets = false;

    @SwitchProperty({
        name:"Auto Scan",
        description:"Automatically scans the dungeon for the first 10 seconds after you warp into a dungeon.",
        category:"Dungeon Map",
        subcategory:"Map"
    })
    autoScan = true;

    @SwitchProperty({
        name:"Darken Unexplored",
        description:"Makes it so that unexplored rooms show up darker on the map.",
        category:"Dungeon Map",
        subcategory:"Map"
    })
    darkenUnexplored = true;

    @SwitchProperty({
        name:"Hide Map In Boss",
        description:"Don't render the map when you enter boss.",
        category:"Dungeon Map",
        subcategory:"Map"
    })
    hideInBoss = false;

    @SwitchProperty({
        name:"Hide Map Outside Dungeon",
        description:"Don't render the map when you're not in a dungeon.",
        category:"Dungeon Map",
        subcategory:"Map"
    })
    hideOutsideDungeon = false;

    @SwitchProperty({
        name:"Reset Map After Dungeon",
        description:"Automatically make the map blank after exiting a dungeon.",
        category:"Dungeon Map",
        subcategory:"Map"
    })
    autoResetMap = true;

    // -------------------------------------------------------------------------------

    @SwitchProperty({
        name:"Wither Doors Esp",
        description:"Draws a baritone box around wither doors. Boxes disappear when you go close to them.\n&8- Suggested by epha & RestOps",
        category:"World",
        subcategory:"Wither Door ESP"
    })
    witherDoorEsp = false;

    @ColorProperty({
        name: 'Wither Door ESP Color',
        description: 'What color the wither door ESP boxes render.',
        category: 'World',
        subcategory: 'Wither Door ESP',
    })
    witherDoorEspColor = Color.RED;

    // --------------------------------------------------------------------------------

    @SwitchProperty({
        name:"Enable Score Calc",
        description:"Shows the score calc under the dungeon map.",
        category:"Score Calculator"
    })
    scoreCalc = true;

    @SwitchProperty({
        name:"Announce 300",
        description:"Says \"300 Score Reached!\" In party chat once you reach 300 score.",
        category:"Score Calculator"
    })
    say300 = true;

    @TextProperty({
        name: "300 Score Reached Messagge",
        description: "The message that will be sent into party chat when 300 score has been reached.",
        category: "Score Calculator",
        placeholder: "300 Score Reached!",
    })
    say300Message = "300 Score Reached!";

    @SwitchProperty({
        name:"Assume Mimic",
        description:"Assumes mimics are killed on floor 6 and 7.",
        category:"Score Calculator"
    })
    assumeMimic = true;

    @SwitchProperty({
        name:"Assume Spirit Pet",
        description:"Assumes the first player to die is using a spirit pet and only subtract 1 score for the death.",
        category:"Score Calculator"
    })
    assumeSpirit = true;

    @SwitchProperty({
        name:"Paul &d❤",
        description:"Adds +10 to the bonus score.",
        category:"Score Calculator"
    })
    ezpzPaul = false;

    
}

export default new Settings